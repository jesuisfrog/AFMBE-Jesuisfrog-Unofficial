## 1.0

## Bug Fixes

- Fix being unable to edit items on PC sheets
- Removed delete button on item categories (bugged and unnecessary) 
- Fix rolls not working

## Changes

- Addressed multiple deprecations
- Added a damage multiplier modifier (Needed as weapons can add a modifier to the characteristic used for damage and there was no way to represent that)